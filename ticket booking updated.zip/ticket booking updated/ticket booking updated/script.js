const wrapper=document.querySelector('.wrapper');
const registerlink=document.querySelector('.register-link')
const btnl=document.querySelector('.btnl');
const Loginlink=document.querySelector('.login-link');
const iconClose=document.querySelector('.icon-close');

registerlink.addEventListener('click',()=>{
    wrapper.classList.add('active');
});

Loginlink.addEventListener('click',()=>{
  wrapper.classList.remove('active');
})

btnl.addEventListener('click',()=>{
    wrapper.classList.add('active-popup');
});

iconClose.addEventListener('click',()=>{
    wrapper.classList.remove('active-popup');
});